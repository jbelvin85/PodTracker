#!/bin/bash
echo "Updating PodTracker..."
cd /var/www/html/PodTracker
git pull origin main
chown -R www-data:www-data .
chmod -R 755 .
echo "PodTracker updated successfully!"

# Optional: restart Flask service
echo "Restarting application service to apply updates..."
sudo systemctl restart podtracker
echo "✅ Service restarted."