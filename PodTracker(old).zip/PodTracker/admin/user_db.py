#!/usr/bin/env python3
import psycopg2
import getpass

# Prompt for PostgreSQL superuser credentials
admin_user = input("Enter PostgreSQL admin username (e.g., postgres): ")
admin_pass = getpass.getpass("Enter PostgreSQL admin password: ")

# Prompt for new app database user credentials
app_user = input("Enter PodTracker DB username to create: ")
app_pass = getpass.getpass("Enter password for PodTracker DB user: ")

# Database name
db_name = "podtracker"

def safe_execute(cur, query, params=None):
    try:
        cur.execute(query, params)
    except psycopg2.errors.DuplicateObject:
        print(f"Object already exists: {query}")
    except Exception as e:
        print(f"Error executing query: {e}\nQuery: {query}")

try:
    conn = psycopg2.connect(
        dbname="postgres",
        user=admin_user,
        password=admin_pass,
        host="localhost"
    )
    conn.autocommit = True
    cur = conn.cursor()

    # Create database user (safe, parameterized)
    safe_execute(cur, f"CREATE USER {app_user} WITH PASSWORD %s;", (app_pass,))
    print(f"User '{app_user}' created or already exists.")

    # Create database
    safe_execute(cur, f"CREATE DATABASE {db_name} OWNER {app_user};")
    print(f"Database '{db_name}' created or already exists.")

    # Grant privileges
    safe_execute(cur, f"GRANT ALL PRIVILEGES ON DATABASE {db_name} TO {app_user};")

    # Connect to the new database
    cur.close()
    conn.close()

    conn = psycopg2.connect(
        dbname=db_name,
        user=admin_user,
        password=admin_pass,
        host="localhost"
    )
    conn.autocommit = True
    cur = conn.cursor()

    # Enable uuid-ossp extension
    safe_execute(cur, "CREATE EXTENSION IF NOT EXISTS \"uuid-ossp\";")

    # Create tables
    schema_sql = """
    CREATE TABLE users (
        user_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        display_name VARCHAR(50) NOT NULL,
        avatar_url TEXT,
        bio TEXT,
        social_links JSONB,
        profile_public BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE decks (
        deck_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        format VARCHAR(50),
        deck_url TEXT,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE games (
        game_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        host_id UUID NOT NULL REFERENCES users(user_id) ON DELETE SET NULL,
        format VARCHAR(50) NOT NULL,
        num_players INT NOT NULL,
        seating_order JSONB,
        status VARCHAR(20) DEFAULT 'active',
        started_at TIMESTAMP DEFAULT NOW(),
        ended_at TIMESTAMP
    );

    CREATE TABLE game_players (
        game_player_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        game_id UUID NOT NULL REFERENCES games(game_id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(user_id),
        guest_name VARCHAR(50),
        deck_id UUID REFERENCES decks(deck_id),
        life_total INT DEFAULT 40,
        poison_counters INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT NOW(),
        CONSTRAINT user_or_guest CHECK (
            (user_id IS NOT NULL AND guest_name IS NULL)
            OR (user_id IS NULL AND guest_name IS NOT NULL)
        )
    );

    CREATE TABLE commander_damage (
        damage_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        game_player_id UUID NOT NULL REFERENCES game_players(game_player_id) ON DELETE CASCADE,
        source_player_id UUID NOT NULL REFERENCES game_players(game_player_id),
        damage_amount INT NOT NULL DEFAULT 0
    );

    CREATE TABLE game_log (
        log_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        game_id UUID NOT NULL REFERENCES games(game_id) ON DELETE CASCADE,
        event_type VARCHAR(50),
        event_data JSONB,
        created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE invitations (
        invite_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        game_id UUID NOT NULL REFERENCES games(game_id) ON DELETE CASCADE,
        inviter_id UUID NOT NULL REFERENCES users(user_id),
        invitee_id UUID NOT NULL REFERENCES users(user_id),
        status VARCHAR(20) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE notifications (
        notification_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
        type VARCHAR(50),
        content TEXT,
        read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE friends (
        friendship_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
        friend_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
        status VARCHAR(20) DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(user_id, friend_id)
    );

    CREATE TABLE pods (
        pod_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        name VARCHAR(100) NOT NULL,
        description TEXT,
        created_by UUID NOT NULL REFERENCES users(user_id) ON DELETE SET NULL,
        created_at TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE pod_memberships (
        membership_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
        pod_id UUID NOT NULL REFERENCES pods(pod_id) ON DELETE CASCADE,
        user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
        joined_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(pod_id, user_id)
    );

    -- Indexes for foreign keys
    CREATE INDEX IF NOT EXISTS idx_decks_user_id ON decks(user_id);
    CREATE INDEX IF NOT EXISTS idx_games_host_id ON games(host_id);
    CREATE INDEX IF NOT EXISTS idx_game_players_game_id ON game_players(game_id);
    CREATE INDEX IF NOT EXISTS idx_game_players_user_id ON game_players(user_id);
    CREATE INDEX IF NOT EXISTS idx_pod_memberships_pod_id ON pod_memberships(pod_id);
    CREATE INDEX IF NOT EXISTS idx_pod_memberships_user_id ON pod_memberships(user_id);
    CREATE INDEX IF NOT EXISTS idx_friends_user_id ON friends(user_id);
    CREATE INDEX IF NOT EXISTS idx_friends_friend_id ON friends(friend_id);
    """
    cur.execute(schema_sql)
    print("All tables created successfully.")

    cur.close()
    conn.close()

    print(f"✅ PodTracker database setup complete. Connect with:\n  psql -U {app_user} -d {db_name}")

except Exception as e:
    print("❌ Error:", e)
