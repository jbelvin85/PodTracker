#!/bin/bash
#
# This script restarts the PodTracker application using the systemd service.

echo "Restarting PodTracker service..."
sudo systemctl restart podtracker
echo "✅ PodTracker service restarted successfully."
