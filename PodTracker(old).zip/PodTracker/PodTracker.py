# PodTracker.py - A self-contained Flask application for user sign-up.

from flask import Flask, request, jsonify, render_template, redirect, url_for
from werkzeug.security import generate_password_hash
import psycopg2
import uuid
import time
import os
import sys

# Create a Flask application instance.
app = Flask(__name__)

# --- Database Configuration ---
# Load database configuration from environment variables for better security.
# Provide sensible defaults for local development.
DB_NAME = os.getenv("DB_NAME", "podtracker")
DB_USER = os.getenv("DB_USER", "podtracker-user")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST", "localhost")

# The database password is required. Exit if not set.
if not DB_PASS:
    print("Error: The DB_PASS environment variable is not set.", file=sys.stderr)
    print("Please set it before running the application.", file=sys.stderr)
    sys.exit(1)

def get_db_connection():
    """
    Establishes and returns a connection to the PostgreSQL database.
    Prints a more detailed error message if the connection fails.
    """
    try:
        conn = psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASS,
            host=DB_HOST
        )
        return conn
    except psycopg2.Error as e:
        print(f"Database connection error: {e}")
        print("Please check your PostgreSQL server is running and the database credentials are correct.")
        return None

@app.route('/')
def index():
    """
    Redirects to the sign-up page as the home page.
    """
    return redirect(url_for('signup_page'))

@app.route('/signup', methods=['GET'])
def signup_page():
    """
    Renders the sign-up form.
    """
    return render_template('sign-up.html')


@app.route('/signup', methods=['POST'])
def signup_post():
    """
    Handles the submitted form data to create a new user and redirects to a results page.
    """
    email = request.form.get('email')
    display_name = request.form.get('username')
    password = request.form.get('password')

    # Basic server-side validation
    if not email or not display_name or not password:
        return redirect(url_for('signup_result', status='error', message='All fields are required.'))

    # Generate a secure hash of the password.
    password_hash = generate_password_hash(password)

    conn = get_db_connection()
    if conn is None:
        # If database connection fails, redirect with a specific error.
        return redirect(url_for('signup_result', status='error', message='Could not connect to the database.'))

    try:
        cur = conn.cursor()
        new_user_id = str(uuid.uuid4())
        sql_insert = """
            INSERT INTO users (user_id, email, display_name, password_hash)
            VALUES (%s, %s, %s, %s);
        """
        cur.execute(sql_insert, (new_user_id, email, display_name, password_hash))
        
        conn.commit()
        
        print(f"Successfully created new user: {display_name} ({email}) with ID: {new_user_id}")
        
        return redirect(url_for('signup_result', status='success', message='Account created successfully!'))
        
    except psycopg2.errors.UniqueViolation:
        conn.rollback()
        return redirect(url_for('signup_result', status='error', message='A user with that email already exists. Please try another.'))
    except psycopg2.Error as e:
        conn.rollback()
        print(f"Error inserting user: {e}")
        return redirect(url_for('signup_result', status='error', message='An unexpected error occurred during sign-up.'))
    finally:
        cur.close()
        conn.close()

@app.route('/signup_result', methods=['GET'])  # FIXED: Changed from /signup-result to match function name
def signup_result():
    """
    Renders a page to display the result of the sign-up process.
    """
    status = request.args.get('status')
    message = request.args.get('message')
    return render_template('signup-result.html', status=status, message=message)

@app.route('/dashboard')
def dashboard():
    """
    A placeholder for the dashboard page.
    """
    return "<h1>Welcome to your Dashboard!</h1>"

if __name__ == '__main__':
    # Run the Flask app in debug mode.
    app.run(debug=True, host='0.0.0.0', port=5000)