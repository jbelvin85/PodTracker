// Very basic service worker
self.addEventListener('install', (event) => {
  console.log('PodTracker installed!');
});

self.addEventListener('fetch', (event) => {
  // Handle requests (for offline support)
});